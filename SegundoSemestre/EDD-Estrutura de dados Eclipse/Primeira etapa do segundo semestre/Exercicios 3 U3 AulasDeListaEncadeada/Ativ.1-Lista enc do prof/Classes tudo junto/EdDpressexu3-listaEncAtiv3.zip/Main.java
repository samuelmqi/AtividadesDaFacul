class TadCelula {
  int valor;
  TadCelula prox;
}

class TadListaEncadeada {
  TadCelula primeiro;
  TadCelula ultimo;
  int tamanho;
  int capacidade;
}

class Main {
  public static void main(String[] args) {
    // declaração
    TadListaEncadeada lista;

    // criar a lista vazia
    lista = new TadListaEncadeada();
    // criando a celula cabeca
    TadCelula cabeca = new TadCelula();
    lista.primeiro = cabeca;
    lista.ultimo = cabeca;
    lista.tamanho = 0;
    lista.capacidade = 15;

    System.out.println("\nPrimeiro:" + lista.primeiro);

    System.out.println("\nUltimo:" + lista.ultimo);

    // lista está vazia
    // equals compara se dois objetos são iguais
    if (lista.primeiro.equals(lista.ultimo)) {
      System.out.println("Lista vazia!\n");
    }
    if (lista.tamanho == 0) {
      System.out.println("Lista vazia!\n");
    }

    // insercao
    for (int i = 2; i < 60; i++) {
      if (lista.tamanho == lista.capacidade) {
        System.out.println("Lista Cheia!");
      } else {
        TadCelula nova = new TadCelula();
        nova.valor = i*2; // pode ser inserido via scanner
        lista.ultimo.prox = nova; //
        lista.ultimo = nova;
        lista.tamanho++;

      }
    }

    // exibir a lista
    TadCelula aux = lista.primeiro.prox;
    while (aux != null) {
      System.out.print("[ " + aux.valor + "] -> ");
      aux = aux.prox;
    }
    System.out.println("NULL");

  }
}