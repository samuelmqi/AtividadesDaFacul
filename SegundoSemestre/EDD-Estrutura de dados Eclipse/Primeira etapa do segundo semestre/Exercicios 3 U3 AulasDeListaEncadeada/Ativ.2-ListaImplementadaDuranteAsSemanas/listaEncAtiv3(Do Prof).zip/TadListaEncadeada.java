class TadListaEncadeada {
  TadCelula primeiro;
  TadCelula ultimo;
  int tamanho;
  int capacidade;

  // construtor da classe
  public TadListaEncadeada(int capacidade) {
    // criando a celula cabeca
    TadCelula cabeca = new TadCelula();
    this.primeiro = cabeca;
    this.ultimo = cabeca;
    this.tamanho = 0;
    this.capacidade = capacidade;    
  }

  public boolean inserir(int valor) {
      if (this.estahCheia()) {
        System.out.println("Lista Cheia!");
        return false;
      } else {
        TadCelula nova = new TadCelula();
        nova.valor = valor; // pode ser inserido via scanner
        this.ultimo.prox = nova; //
        this.ultimo = nova;
        this.tamanho++;

        return true;
      }

  }

  public boolean pesquisar(int valor) {
    return false;
  }

  public boolean remover(int valor) {
    return false;
  }

  public void exibir() {
    // exibir a lista
    TadCelula aux = this.primeiro.prox;
    while (aux != null) {
      System.out.print("[ " + aux.valor + "] -> ");
      aux = aux.prox;
    }
    System.out.println("NULL");
  }

  public boolean alterar(int valor, int novoValor) {
    return false;
  }

  public boolean estahCheia() {
    return this.tamanho == this.capacidade;
  }

  public boolean estahVazia() {
    return this.primeiro.equals(this.ultimo);
  }

}