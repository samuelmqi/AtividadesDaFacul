class Main {
  public static void main(String[] args) {
    // criar a lista vazia
    TadListaEncadeada lista = new TadListaEncadeada(10);

    System.out.println("\nPrimeiro:" + lista.primeiro);
    System.out.println("\nUltimo:" + lista.ultimo);

    // lista está vazia
    // equals compara se dois objetos são iguais
    if (lista.estahVazia()) {
      System.out.println("Lista vazia!\n");
    }

    // insercao
    int [] v = {3,8,5,1,9,4,6};
    for (int i = 0; i < v.length; i++) {
      System.out.println("Inserindo " + (v[i]));
      lista.inserir(v[i]);
      lista.exibir();
    }

    // pesquisa por uma chave

    // remoção a partir de uma chave

    // inserção ordenada

  }

} 