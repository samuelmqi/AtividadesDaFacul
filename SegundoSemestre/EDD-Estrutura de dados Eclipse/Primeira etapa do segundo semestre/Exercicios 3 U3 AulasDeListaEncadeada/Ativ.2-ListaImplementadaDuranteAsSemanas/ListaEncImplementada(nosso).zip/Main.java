class Main {
  public static void main(String[] args) {
    // criar a lista vazia
    TadListaEncadeada lista = new TadListaEncadeada(11);

    System.out.println("\nPrimeiro:" + lista.primeiro);
    System.out.println("\nUltimo:" + lista.ultimo);

    // lista está vazia
    // equals compara se dois objetos são iguais
    if (lista.estahVazia()) {
      System.out.println("Lista vazia!\n");
    }

    // insercao
    int[] v = { 3, 9, 5, 4, 8, 15, 10 };
    for (int i = 0; i < v.length; i++) {
      System.out.println("Inserindo " + (v[i]));
      lista.inserir(v[i]);
      lista.exibir();
    }

    // pesquisa por uma chave
    boolean achou = lista.pesquisar(10);
    if (achou) {
      lista.exibir();
      System.out.println("Achou! 🎉 🎊 🎉  ");
    } else {
      System.out.println("Não encontrado: 😥");
    } 
    // remoção a partir de uma chave
      boolean removeu = lista.remover(15); {
      if (removeu) {
        lista.exibir();
        System.out.println("Foi removido");
      }
    } 
   
    // inserção ordenada
    boolean ordenado = lista.insercaoOrdenada(3);
    if (ordenado) {
      lista.exibir();
      System.out.println("Foi alocado.");
    } else {
      System.out.println("Não foi alocado.");
    }
  }

}