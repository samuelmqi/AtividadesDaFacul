class TadListaEncadeada {
  TadCelula primeiro;
  TadCelula ultimo;
  int tamanho;
  int capacidade;

  // construtor da classe
  public TadListaEncadeada(int capacidade) {
    // criando a celula cabeca
    TadCelula cabeca = new TadCelula();
    this.primeiro = cabeca;
    this.ultimo = cabeca;
    this.tamanho = 0;
    this.capacidade = capacidade;
  }

  public boolean inserir(int valor) {
    if (this.estahCheia()) {
      System.out.println("Lista Cheia!");
      return false;
    } else {
      TadCelula nova = new TadCelula();
      nova.valor = valor; // pode ser inserido via scanner
      this.ultimo.prox = nova; //
      this.ultimo = nova;
      this.tamanho++;

      return true;
    }

  }

  public boolean pesquisar(int valor) {
    System.out.println();
    System.out.println("Buscando o valor: " + valor);
    TadCelula aux = this.primeiro.prox;
    while (aux != null) {
      if (valor == aux.valor) {
        return true;
      }
      aux = aux.prox;
    }
    return false;
  }

  public boolean remover(int valor) {
    System.out.println();
    System.out.println("Buscando o valor: " + valor);
    
    TadCelula aux = this.primeiro.prox;
    TadCelula anterior = this.primeiro;
    while (aux.prox != null && aux.valor != valor) {
      anterior = aux;
      aux = aux.prox;

    }
    // executar remoção
    if (valor != aux.valor) {
      System.out.println("O número não está na lista.");
    } else {
      this.ultimo = anterior.prox;
      anterior.prox = aux.prox;
      this.tamanho--;
      return true;

    }
    return false;
  }

  public boolean insercaoOrdenada(int valor) {
    System.out.println();
    System.out.println("Alocando o valor: " + valor);
    TadCelula anterior = null;
    TadCelula aux = primeiro;

    while (aux != null && aux.valor < valor) {
      anterior = aux;
      aux = aux.prox;
    }

    TadCelula nova = new TadCelula();
    nova.valor = valor;

    if (anterior == null) {
      nova.prox = primeiro;
      primeiro = nova;
    } else {
      nova.prox = anterior.prox;
      anterior.prox = nova;
    }
    return true;
  }

  public void exibir() {
    // exibir a lista

    TadCelula aux = this.primeiro.prox;
    while (aux != null) {
      System.out.print("[" + aux.valor + "] -> ");
      aux = aux.prox;
    }
    System.out.println("NULL");
  }

  public boolean alterar(int valor, int novoValor) {
    return false;
  }

  public boolean estahCheia() {
    return this.tamanho == this.capacidade;
  }

  public boolean estahVazia() {
    return this.primeiro.equals(this.ultimo);
  }

}