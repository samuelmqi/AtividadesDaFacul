import java.util.Scanner; 

class Main {
  

  public static void main(String[] args) {
       int v = 0;
        Scanner ler = new Scanner(System.in);
        System.out.println("informe a quantidade de numeros  desejado:");
        v = ler.nextInt();
       TadListaEncadeada lista = new TadListaEncadeada(v);
	
         
	     	     
	for ( int i = 0; i <v ; i++) {
        	System.out.println("informe o numero desejado:");
          lista.inserir(ler.nextDouble());
        	lista.exibir();  
        
     }

    lista.exibirMedia();
    
    lista.exibirMaiorEMenor();
 
  }

}
