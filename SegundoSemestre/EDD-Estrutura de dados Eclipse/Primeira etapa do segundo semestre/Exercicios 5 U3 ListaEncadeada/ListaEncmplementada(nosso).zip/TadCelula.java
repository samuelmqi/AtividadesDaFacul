class TadCelula {
  double valor;
  TadCelula prox;
}
