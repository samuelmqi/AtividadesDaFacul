class TadListaEncadeada {
  TadCelula primeiro;
  TadCelula ultimo;
  int tamanho;
  int capacidade;
  

  
  public TadListaEncadeada(int capacidade) {
    // criando a celula cabeca
    TadCelula cabeca = new TadCelula();
    this.primeiro = cabeca;
    this.ultimo = cabeca;
    this.tamanho = 0;
    this.capacidade = capacidade;
  }

  public boolean inserir(double valor) {
      TadCelula nova = new TadCelula();
      nova.valor = valor;// pode ser inserido via scanner
      this.ultimo.prox = nova; //
      this.ultimo = nova;
      this.tamanho++;

      return true;

  }
  

  public void exibir() {
    // exibir a lista

    TadCelula aux = this.primeiro.prox;
    while (aux != null) {
      System.out.print("[" + aux.valor + "] -> ");
      aux = aux.prox;
    }
    System.out.println("NULL");
  }

    public void exibirMedia() {
    // exibir a media

    TadCelula aux = this.primeiro.prox;
    double soma = 0.0;
    while (aux != null) {
     soma= soma + aux.valor; 

      aux = aux.prox;
    }
    double media = soma/tamanho;

    System.out.println("A media e: "+media);
    }
     
     public void exibirMaiorEMenor() {
    // exibir Maior e Menor

      double menor = 0.0;
      double maior = 0.0;

    TadCelula aux = this.primeiro.prox;
    while (aux != null) {
      if (this.estahVazia()) {
      System.out.println("Lista esta vazia!");
      }

      else{
      if (aux.valor>maior){
        maior= aux.valor;
        }

         if (aux.valor<maior){
        menor= aux.valor;
        }
        
        aux = aux.prox;
      }
      
      }
      System.out.println("o maior valor é"+ maior);
      System.out.println("o menor valor é"+ menor);
       }
    
    public boolean estahVazia() {
    return this.primeiro.equals(this.ultimo);
  }

  
     
    }

