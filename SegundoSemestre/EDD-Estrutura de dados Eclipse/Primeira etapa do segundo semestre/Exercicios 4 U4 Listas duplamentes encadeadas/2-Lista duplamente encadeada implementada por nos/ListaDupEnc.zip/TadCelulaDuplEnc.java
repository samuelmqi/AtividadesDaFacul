class TadCelulaDuplEnc {
  int valor;
  TadCelulaDuplEnc prox;
  TadCelulaDuplEnc anterior;
}