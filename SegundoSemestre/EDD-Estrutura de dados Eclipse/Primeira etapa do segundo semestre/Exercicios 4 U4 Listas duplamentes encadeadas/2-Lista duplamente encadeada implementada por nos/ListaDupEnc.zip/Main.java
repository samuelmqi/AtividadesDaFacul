class Main {
  public static void main(String[] args) {

    TadListaDuplEnc lista = new TadListaDuplEnc(9);
    lista.exibir();

    int v[] = {4, 6, 5, 7, 1, 9};
    for (int i = 0; i < v.length; i++) {
      System.out.println("\nTentando Inserir valor " + v[i]);
      lista.inserir(v[i]);
      lista.exibir();
    }

    if (lista.pesquisar(7)){
      System.out.println("7: achou!");
      System.out.println();
    } else {
      System.out.println("7: não achou!");
      System.out.println();
    }

    if (lista.pesquisar(8)){
      System.out.println("8: achou!");
      System.out.println();
    } else {
      System.out.println("8: não achou!");
      System.out.println();
    }

     System.out.println("Impressão inversa.");
    lista.exibirInvertido();

    lista.retirar(10);
    System.out.println();
    lista.exibir();
    System.out.println();
    System.out.println("Impressão inversa.");
    lista.exibirInvertido(); 

    System.out.println();
    System.out.println("Lista invertida.");
    lista.inverter();
    System.out.println();

    lista.inserirOrdenado(10);
    lista.exibir();

    int vetor [] = {5, 2, 4};
	  lista.inserirVarios(vetor);
  }
}