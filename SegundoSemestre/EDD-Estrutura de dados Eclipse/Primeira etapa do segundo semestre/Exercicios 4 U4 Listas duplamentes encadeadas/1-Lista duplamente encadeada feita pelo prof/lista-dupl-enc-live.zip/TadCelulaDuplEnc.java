class TadCelulaDuplEnc {
  int valor;
  TadCelulaDuplEnc prox;
  TadCelulaDuplEnc ant;
}