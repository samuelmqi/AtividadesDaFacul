public class TadPilha {

	public static final int VAZIO = -1;

	TadCelula topo;
	TadCelula fundo;
	int tamanho;
	int capacidade;

	// construtor
	public TadPilha(int capacidade) {
		// criar celula cabeça
		TadCelula cabeca = new TadCelula();
		this.topo = cabeca;
		this.fundo = cabeca;
		this.tamanho = 0;
		this.capacidade = capacidade;
	}

	public void exibir() {
		System.out.println("\nTAD Pilha: ");
		System.out.println(String.format("Tamanho/Capacidade: %d/%d\n", tamanho, capacidade));

		TadCelula aux = topo.prox;
		System.out.print("TOPO -> ");
		while (aux != null) {
			System.out.print(aux);
			aux = aux.prox;
		}
		System.out.println("FUNDO\n");
	}

	public boolean estahCheia() {
		return tamanho == capacidade;
	}

	public boolean estahVazia() {
		// return tamanho == 0;
		return topo == fundo;
	}

	public boolean empilhar(int chave) { // PUSH
		// verificar se está cheia
		if (estahCheia()) {
			System.out.println("Pilha está cheia!");
			return false;
		}

		TadCelula nova = new TadCelula();
		topo.valor = chave;
		nova.prox = topo;
		topo = nova; // nova celula cabeça
		tamanho++;

		return true;
	}

	public int desempilhar() { // POP
		// verificar se a pilha está vazia
		if (estahVazia()) {
			System.out.println("Pilha está vazia!");
			return VAZIO;
		}

		TadCelula aux = topo.prox; // topo da pilha

		if (aux.prox == null) {
			fundo = topo; // pilha vazia;
			topo.prox = null;
		} else {
			topo.prox = aux.prox;
		}

		tamanho--;
		// retornar o elemento desempilhado
		return aux.valor;

	}

	public int obterTopo() {

		if (estahVazia()) {
			System.out.println("Pilha está vazia!");
			return VAZIO;
		}

		this.exibir();

		System.out.println("O valor atual no topo da lista é: " + topo.prox.valor);
		return topo.prox.valor;

	}

	public boolean pesquisar(int chave) {
		TadCelula aux = topo.prox;
		// enquanto não chegar no final E o valor na celula for diferente do valor de
		// pesquisa
		while (aux != null && aux.valor != chave) {
			aux = aux.prox;
		}

		this.exibir();

		if (aux == null) {
			System.out.println("Valor não encontrado.");
			return false; // 1a condição, não achou
		} else {
			System.out.println("Valor encontrado.");
			return true; // 2a condição, achou
		}
	}

	public void inverte() {
		TadPilha aux1 = new TadPilha(capacidade);
		TadPilha aux2 = new TadPilha(capacidade);

		while (!estahVazia()) {
			int removido = desempilhar();
			aux1.empilhar(removido);
		}

		while (!aux1.estahVazia()) {
			aux2.empilhar(aux1.desempilhar());
		}

		while (!aux2.estahVazia()) {
			empilhar(aux2.desempilhar());
		}

	}
}