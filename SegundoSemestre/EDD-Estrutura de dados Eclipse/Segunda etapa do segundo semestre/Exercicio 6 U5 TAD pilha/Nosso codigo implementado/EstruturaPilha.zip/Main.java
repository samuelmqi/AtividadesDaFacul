import java.util.Scanner;

class Main {

	static void exibirMenu() {
		System.out.println("======================================");
		System.out.println("EdD - TAD Pilha\n");

		System.out.println("1. Criar nova pilha");
		System.out.println("2. Exibir pilha");
		System.out.println("3. Empilhar novo item");
		System.out.println("4. Desempilhar item");
		System.out.println("5. Está cheia?");
		System.out.println("6. Está vazia?");
		System.out.println("7. Opter topo");
		System.out.println("8. Pesquisar por uma chave");
		System.out.println("9. Inverter a pilha");
		System.out.println("10. Sair\n");

		System.out.print("Escolha uma das opções acima (1-10): ");
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		TadPilha pilha = null;
		@SuppressWarnings("unused")
		int op = 0, chave = 0;
		@SuppressWarnings("unused")
		boolean resultado;

		while (op != 10) {
			exibirMenu();
			op = sc.nextInt();

			switch (op) {
			case 1:
				System.out.print("Digite a capacidade desejada: ");
				int capacidade = sc.nextInt();

				pilha = new TadPilha(capacidade);

				break;
			case 2:
				pilha.exibir();
				break;
			case 3:
				for (int i = 0; i < pilha.capacidade; i++) {
					System.out.print("Digite o valor para inserir: ");
					pilha.empilhar(sc.nextInt());
				}
				break;
			case 4:
				pilha.desempilhar();
				pilha.exibir();
				break;
			case 5:
				if (pilha.estahCheia()) {
					System.out.println("A pilha está cheia.");
					pilha.exibir();
				} else if (pilha.tamanho != pilha.capacidade) {
					System.out.println("Ainda tem espaço.");
					pilha.exibir();
				} else {
					System.out.println("Ainda tem espaço.");
					pilha.exibir();
				}
				break;
			case 6:
				if (pilha.estahVazia()) {
					System.out.println("A pilha está vazia.");
					pilha.exibir();
				} else if (pilha.tamanho != pilha.capacidade) {
					System.out.println("Ainda tem espaço.");
					pilha.exibir();
				} else {
					System.out.println("Não tem espaço.");
					pilha.exibir();
				}
				break;
			case 7:
				pilha.obterTopo();
				break;
			case 8:
				System.out.print("Digite o valor para pesquisar: ");
				pilha.pesquisar(sc.nextInt());
				break;
			case 9:
				pilha.inverte();
				System.out.println("Pilha Invertida: ");
				pilha.exibir();
				break;
			}

			System.out.println();
		}

		sc.close();
	}

}