class TadPilha {

  public static final int VAZIO = -1;

  TadCelula topo;
  TadCelula fundo;
  int tamanho;
  int capacidade;

  // construtor
  public TadPilha(int capacidade) {
    // criar celula cabeça
    TadCelula cabeca = new TadCelula();
    this.topo = cabeca;
    this.fundo = cabeca;
    this.tamanho = 0;
    this.capacidade = capacidade;
  }

  public void exibir() {
    System.out.println("\n\nTAD Pilha: ");
    System.out.println(String.format("Tamanho/Capacidade: %d/%d\n", tamanho, capacidade));

    TadCelula aux = topo.prox;
    System.out.print("TOPO -> ");
    while (aux != null) {
      System.out.print(aux);
      aux = aux.prox;
    }
    System.out.println("FUNDO\n\n");
  }

  public boolean estahCheia() {
    return tamanho == capacidade;
  }

  public boolean estahVazia() {
    //return tamanho == 0;
    return topo == fundo;
  }

  public boolean empilhar(int chave) { // PUSH
    // verificar se está cheia
    if (estahCheia()) {
      System.out.println("Pilha está cheia!");
      return false;
    }

    TadCelula nova = new TadCelula();
    topo.valor = chave;
    nova.prox = topo;
    topo = nova; // nova celula cabeça
    tamanho++;

    return true;
  }

  public int desempilhar() { // POP
    // verificar se a pilha está vazia
    if (estahVazia()) {
      System.out.println("Pilha está vazia!");
      return VAZIO;
    }

    TadCelula aux = topo.prox; // topo da pilha
    
    if (aux.prox == null) {
      fundo = topo; // pilha vazia;
      topo.prox = null;
    } else {
      topo.prox = aux.prox;
    }

    tamanho--;

    // retornar o elemento desempilhado
    return aux.valor;
  }
}