import java.util.Scanner;

class Main {

  static void exibirMenu() {
    System.out.println("======================================");
    System.out.println("EdD - TAD Pilha\n");

    System.out.println("1. Criar nova pilha");
    System.out.println("2. Exibir pilha");
    System.out.println("3. Empilhar novo item");
    System.out.println("4. Desempilhar item");
    System.out.println("5. Está cheia?");
    System.out.println("6. Está vazia?");
    System.out.println("7. Opter topo");
    System.out.println("8. Pesquisar por uma chave");
    System.out.println("9. Inverter a pilha");
    System.out.println("10. Sair\n");

    System.out.println("Escolha uma das opções acima (1-10):");
  }

 public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        TadPilha pilha = null;
        int op = 0, chave = 0;
        boolean resultado;

        while (op != 10) {
            exibirMenu();

            op = sc.nextInt();

            switch (op) {
                case 1:
                    System.out.println("Digite a capacidade desejada:");
                    int capacidade = sc.nextInt();

                    pilha = new TadPilha(capacidade);

                    break;
                case 2:

                    break;
                case 3:

                    break;
                case 4:

                    break;
                case 5:

                    break;
                case 6:

                    break;
                case 7:

                    break;
                case 8:

                    break;
                case 9:

                    break;
            }

          pilha.exibir();
        }

        sc.close();
    }

}