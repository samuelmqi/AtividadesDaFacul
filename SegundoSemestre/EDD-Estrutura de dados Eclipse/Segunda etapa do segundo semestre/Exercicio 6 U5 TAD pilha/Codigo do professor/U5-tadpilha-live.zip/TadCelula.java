class TadCelula {
  int valor;
  TadCelula prox;

  public String toString() {
    return "[ " + valor + " ] -> ";
  }
}